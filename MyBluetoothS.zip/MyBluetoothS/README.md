# MyBluetoothChat
这是关于蓝牙通信的app，两个客户端连接可以通信，发送文字，表情，可以设置聊天背景。
