package com.example.mybluetoothS;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
//import com.tbruyelle.rxpermissions2.RxPermissions;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.app.ActivityCompat;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.chad.library.adapter.base.BaseQuickAdapter;

//import com.tbruyelle.rxpermissions2.RxPermissions;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class StudentActivity<ActivityResultLauncher> extends AppCompatActivity {
    ProgressBar pbSearchBle;
    private Button On,Off,Visible,list,change,compare,input_n;
    private BluetoothAdapter BA;
    private Set<BluetoothDevice> pairedDevices;
    private ArrayList<String> mDeviceList = new ArrayList<String>();
    private ListView lv_p,lv_a;
    private TextView tv_search,tv_click_advice;
    private String stu_id = "-1";
    private int time=0;
    private static final int REQUEST_CODE_GPS = 1;
    final long lTimeToGiveUp_ms = System.currentTimeMillis() + 10000;
    String sNewName = "00000000";
    private static int REQUEST_ENABLE_BLUETOOTH = 1;//请求码

    BluetoothAdapter bluetoothAdapter;//蓝牙适配器

    private TextView scanDevices;//扫描设备
    private LinearLayout loadingLay;//加载布局
    private RecyclerView rv;//蓝牙设备展示列表


//    private RxPermissions rxPermissions = new RxPermissions(this);//权限请求


    List<BluetoothDevice> deviceList = new ArrayList<>();//数据来源
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
//        On = (Button)findViewById(R.id.button_on);
//        Off = (Button)findViewById(R.id.button_off);
        Visible = (Button)findViewById(R.id.button_get_vis);
        list = (Button)findViewById(R.id.button_list);
//        change = (Button)findViewById(R.id.button_change);
//        compare = (Button)findViewById(R.id.button_compare);
//        input_n = (Button)findViewById(R.id.button_input);

//        lv_p = (ListView)findViewById(R.id.listView_p);
//        lv_a = (ListView)findViewById(R.id.listView_a);
//
//        tv_search = (TextView)findViewById(R.id.tv_search);
        tv_click_advice= (TextView)findViewById(R.id.tv_click_advice);

        pbSearchBle=findViewById(R.id.progress_ser_bluetooth);

        BA = BluetoothAdapter.getDefaultAdapter();
        if (BA == null) {
            // Device doesn't support Bluetooth
            Toast.makeText(getApplicationContext(),"Your device doesn't support Bluetooth",
                    Toast.LENGTH_LONG).show();
        }

    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(Lreceiver);
        time=0;
        super.onDestroy();
    }
    // Create a BroadcastReceiver for ACTION_FOUND.
    private BroadcastReceiver Lreceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.i("BTlist", " run"+intent.getAction());
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                mDeviceList.add(device.getName() + ": " + device.getAddress() + "\n");
                Log.i("BTlist", device.getName() + ": " + device.getAddress() + "\n");
                lv_a.setAdapter(new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, mDeviceList));
                tv_search.setText("Devides searched");
                pbSearchBle.setVisibility(View.GONE);
//                textView.setText(mDeviceList.toString());
            }
        }
    };
    public void on(View view){
        if (!BA.isEnabled()) {
            Intent turnOn = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(turnOn, 0);
            Toast.makeText(getApplicationContext(),"Turned on"
                    ,Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(getApplicationContext(),"Already on",
                    Toast.LENGTH_LONG).show();
        }
    }

    public void listConnected(View view){
        pairedDevices = BA.getBondedDevices();
        BA.cancelDiscovery();
        ArrayList list = new ArrayList();
        for(BluetoothDevice bt : pairedDevices)
            list.add(bt.getName());

        Toast.makeText(getApplicationContext(),"Showing Paired Devices",
                Toast.LENGTH_SHORT).show();
        final ArrayAdapter adapter = new ArrayAdapter
                (this,android.R.layout.simple_list_item_1, list);
        lv_p.setAdapter(adapter);
    }
/**
        * 蓝牙广播过滤器
 * 蓝牙状态改变
 * 找到设备
 * 搜索完成
 * 开始扫描
 * 状态改变
 *
         * @return
         */
    public IntentFilter makeFilter() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);//蓝牙状态改变的广播
        filter.addAction(BluetoothDevice.ACTION_FOUND);//找到设备的广播
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);//搜索完成的广播
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);//开始扫描的广播
        filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);//状态改变
        return filter;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_GPS) {
            LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                Toast.makeText(this, "用户打开定位服务", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "用户关闭定位服务", Toast.LENGTH_LONG).show();
            }
        }
    }

//    public void listAvailable(View view){
//        on(view);
//        if(time==0) {
//            inputName(view);
//            time++;
//        }
//        tv_click_advice.setVisibility(View.INVISIBLE);

//        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
//
//        // https://developer.android.google.cn/guide/components/intents-filters?hl=zh-cn#ExampleSend
//        // https://developer.android.google.cn/reference/android/content/Intent?hl=zh-cn#resolveActivity(android.content.pm.PackageManager)
//        // 判断是否有合适的应用能够处理该 Intent，并且可以安全调用 startActivity()。
//        if (intent.resolveActivity(getPackageManager()) != null) {
//            startActivityForResult(intent, REQUEST_CODE_GPS);
//        } else {
//            Toast.makeText(this, "该设备不支持位置服务", Toast.LENGTH_SHORT).show();
//        }
//
//        tv_search.setText("Searching...");
//        pbSearchBle.setVisibility(View.VISIBLE);
//        Toast.makeText(getApplicationContext(),"Searching...",
//                Toast.LENGTH_SHORT).show();
//        Log.i("BTlist", "start list");
//        permissionRequire();
//        Log.i("BTlist", "start search");
//        BA.startDiscovery();
//        // Register for broadcasts when a device is discovered.
//        IntentFilter Lfilter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
//        registerReceiver(Lreceiver, Lfilter);
//
//    }
//    /**
//     * check Android version
//     */
//    private void checkVersion() {
//        if (Build.VERSION.SDK_INT >= 23) {//6.0 or above
//            permissionsRequest();// ask for permission
//        } else {// below 6.0
//            initBlueTooth();//init directly
//        }
//    }

//    /**
//     * Dynamic permission application
//     */
//    private void permissionsRequest() {
//        rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION)
//                .subscribe(granted -> {
//                    if (granted) {
//                        initBlueTooth();
//                    } else {
//                        showMsg("权限未开启");
//                    }
//                });
//    }
    /**
     * init bluetooth settings
     */
    private void initBlueTooth() {
        IntentFilter intentFilter = new IntentFilter();//创建一个IntentFilter对象
        intentFilter.addAction(BluetoothDevice.ACTION_FOUND);//获得扫描结果
        intentFilter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);//绑定状态变化
        intentFilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);//开始扫描
        intentFilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);//扫描结束

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();//获取蓝牙适配器
    }
    /**
     * 消息提示
     *
     * @param msg 消息内容
     */
    private void showMsg(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

//    /**
//     * Scan nearby devices
//     */
//    public void listAvailable(View view){
//        if (view.getId() == R.id.iv_ser_ble_status) {
//            if (bluetoothAdapter != null) {//是否支持蓝牙
//                if (bluetoothAdapter.isEnabled()) {//打开
//                    //开始扫描周围的蓝牙设备,如果扫描到蓝牙设备，通过广播接收器发送广播
//                    if (mAdapter != null) {//当适配器不为空时，这时就说明已经有数据了，所以清除列表数据，再进行扫描
//                        deviceList.clear();
////                        mAdapter.notifyDataSetChanged();
//                    }
//                    bluetoothAdapter.startDiscovery();
//                } else {//未打开
//                    Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
//                    startActivityForResult(intent, REQUEST_ENABLE_BLUETOOTH);
//                }
//            } else {
//                showMsg("你的设备不支持蓝牙");
//            }
//        }
//    }

//    /**
//     * 广播接收器
//     */
//    private class BluetoothReceiver extends BroadcastReceiver {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            String action = intent.getAction();
//            switch (action) {
//                case BluetoothDevice.ACTION_FOUND://扫描到设备
////                    showDevicesData(context, intent);//数据展示
//                    break;
//                case BluetoothDevice.ACTION_BOND_STATE_CHANGED://设备绑定状态发生改变
//                    mAdapter.changeBondDevice();//刷新适配器
//                    break;
//                case BluetoothAdapter.ACTION_DISCOVERY_STARTED://开始扫描
//                    loadingLay.setVisibility(View.VISIBLE);//显示加载布局
//                    break;
//                case BluetoothAdapter.ACTION_DISCOVERY_FINISHED://扫描结束
//                    loadingLay.setVisibility(View.GONE);//隐藏加载布局
//                    break;
//            }
//        }
//    }

//    /**
//     * 显示蓝牙设备信息
//     *
//     * @param context 上下文参数
//     * @param intent  意图
//     */
//    private void showDevicesData(Context context, Intent intent) {
//        getBondedDevice();//获取已绑定的设备
//        //获取周围蓝牙设备
//        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
//
//        if (deviceList.indexOf(device) == -1) {//防止重复添加
//
//            if (device.getName() != null) {//过滤掉设备名称为null的设备
//                deviceList.add(device);
//            }
//        }
//        mAdapter = new DeviceAdapter(R.layout.item_device_list,deviceList);
//        rv.setLayoutManager(new LinearLayoutManager(context));
//        rv.setAdapter(mAdapter);
//
//        mAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
//            @Override
//            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
//                //点击时获取状态，如果已经配对过了就不需要在配对
//                if (deviceList.get(position).getBondState() == BluetoothDevice.BOND_NONE) {
//                    createOrRemoveBond(1, deviceList.get(position));//开始匹配
//                } else {
//                    showDialog("确定要取消配对吗？", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            //取消配对
//                            createOrRemoveBond(2, deviceList.get(position));//取消匹配
//                        }
//                    });
//                }
//            }
//        });
//    }
    /**
     * 获取已绑定设备
     */
    private void getBondedDevice() {
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {//如果获取的结果大于0，则开始逐个解析
            for (BluetoothDevice device : pairedDevices) {
                if (deviceList.indexOf(device) == -1) {//防止重复添加
                    if (device.getName() != null) {//过滤掉设备名称为null的设备
                        deviceList.add(device);
                    }
                }
            }
        }
    }
    /**
     * 创建或者取消匹配
     *
     * @param type   处理类型 1 匹配  2  取消匹配
     * @param device 设备
     */
    private void createOrRemoveBond(int type, BluetoothDevice device) {
        Method method = null;
        try {
            switch (type) {
                case 1://开始匹配
                    method = BluetoothDevice.class.getMethod("createBond");
                    method.invoke(device);
                    break;
                case 2://取消匹配
                    method = BluetoothDevice.class.getMethod("removeBond");
                    method.invoke(device);
                    deviceList.remove(device);//清除列表中已经取消了配对的设备
                    break;
            }
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

    }


//    /**
//     * 弹窗
//     *
//     * @param dialogTitle     标题
//     * @param onClickListener 按钮的点击事件
//     */
//    private void showDialog(String dialogTitle, @NonNull DialogInterface.OnClickListener onClickListener) {
//        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
//        builder.setMessage(dialogTitle);
//        builder.setPositiveButton("确定", onClickListener);
//        builder.setNegativeButton("取消", null);
//        builder.create().show();
//    }


    //    /**
//     * 获取已绑定设备
//     */
//    private void getBondedDevice() {
//        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
//        if (pairedDevices.size() > 0) {//如果获取的结果大于0，则开始逐个解析
//            for (BluetoothDevice device : pairedDevices) {
//                if (list.indexOf(device) == -1) {//防止重复添加
//                    if (device.getName() != null) {//过滤掉设备名称为null的设备
//                        list.add(device);
//                    }
//                }
//            }
//        }
//    }
//    /**
//     * 显示蓝牙设备信息
//     *
//     * @param context 上下文参数
//     * @param intent  意图
//     */
//    private void showDevicesData(Context context, Intent intent) {
//        getBondedDevice();//获取已绑定的设备
//        //获取周围蓝牙设备
//        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
//
//        if (list.indexOf(device) == -1) {//防止重复添加
//
//            if (device.getName() != null) {//过滤掉设备名称为null的设备
//                list.add(device);
//            }
//        }
//        mAdapter = new DeviceAdapter(R.layout.item_device_list, list);
//        rv.setLayoutManager(new LinearLayoutManager(context));
//        rv.setAdapter(mAdapter);
//
//        mAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
//            @Override
//            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
//                //点击时获取状态，如果已经配对过了就不需要在配对
//                if (list.get(position).getBondState() == BluetoothDevice.BOND_NONE) {
//                    createOrRemoveBond(1, list.get(position));//开始匹配
//                } else {
//                    showDialog("确定要取消配对吗？", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            //取消配对
//                            createOrRemoveBond(2, list.get(position));//取消匹配
//                        }
//                    });
//                }
//            }
//        });
//    }
    private void permissionRequire() {

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        Log.i("BTlist", "permission get");
    }

    public void off(View view){
        BA.disable();
        Toast.makeText(getApplicationContext(),"Turned off" ,
                Toast.LENGTH_LONG).show();
    }

    public void change(View view){
        Log.i("BTchange", "start change");
        if (BA != null)
        {
            Log.i("BTchange", "BA exist");
            String sOldName = BA.getName();
            if (sOldName.equalsIgnoreCase(sNewName) == false)
            {
                final Handler myTimerHandler = new Handler();
                BA.enable();
                myTimerHandler.postDelayed(
                        new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                Log.i("BTchange", "start run");
                                if (BA.isEnabled())
                                {
                                    BA.setName(sNewName);
                                    Log.i("BTchange", "start set");
                                    if (sNewName.equalsIgnoreCase(BA.getName()))
                                    {
                                        Log.i("BTchange", "Updated BT Name to " + BA.getName());
                                        Toast.makeText(getApplicationContext(),"new name" + BA.getName(),
                                                Toast.LENGTH_LONG).show();
//                                        BA.disable();
                                    }
                                }
                                Log.i("BTchange", "Waiting1...");
                                if ((sNewName.equalsIgnoreCase(BA.getName()) == false) && (System.currentTimeMillis() < lTimeToGiveUp_ms))
                                {
                                    Log.i("BTchange", "Waiting2...");
                                    myTimerHandler.postDelayed(this, 500);
                                    if (BA.isEnabled())
                                        Log.i("BTchange", "Update BT Name: waiting on BT Enable");
                                    else
                                        Log.i("BTchange", "Update BT Name: waiting for Name (" + sNewName + ") to set in");
                                }
                            }
                        } , 500);
            }
        }
    }

    public void compare(View view){
        Toast.makeText(getApplicationContext(),"your "+sNewName
                ,Toast.LENGTH_SHORT).show();
        Toast.makeText(getApplicationContext(),"system "+BA.getName()
                ,Toast.LENGTH_SHORT).show();

        if (sNewName.equalsIgnoreCase(BA.getName()))
        {
            Toast.makeText(getApplicationContext(),"same"
                    ,Toast.LENGTH_LONG).show();
        }else {
            Toast.makeText(getApplicationContext(), "not"
                    , Toast.LENGTH_LONG).show();
        }
    }

    public void inputName(View view){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Your Student ID");

// Set up the input
            final EditText input = new EditText(this);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
            input.setInputType(InputType.TYPE_CLASS_NUMBER);
            input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
            builder.setView(input);

// Set up the buttons
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    stu_id = input.getText().toString();
                    sNewName = stu_id;
                    TextView tv_stu_id = (TextView) findViewById(R.id.stu_id);
                    tv_stu_id.setText("Your ID: " + stu_id);
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            builder.show();

    }

    public void visible(View view){
        Intent getVisible = new Intent(BluetoothAdapter.
                ACTION_REQUEST_DISCOVERABLE);
        startActivityForResult(getVisible, 0);

    }
//    //连接蓝牙设备的异步任务
//    class ConnectTask extends AsyncTask<String,String,String>
//    {
//

//        @Override
//        protected String doInBackground(String... params) {
//            // TODO Auto-generated method stub
//            BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(params[0]);
//
//            try {
//
//                btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
//
//
//                btSocket.connect();
//
//                Log.e("error", "ON RESUME: BT connection established, data transfer link open.");
//
//            } catch (IOException e) {
//
//                try {
//                    btSocket.close();
//                    return "Socket 创建失败";
//
//                } catch (IOException e2) {
//
//                    Log .e("error","ON RESUME: Unable to close socket during connection failure", e2);
//                    return "Socket 关闭失败";
//                }
//
//            }
//            //取消搜索
//            mBluetoothAdapter.cancelDiscovery();
//
//            try {
//                outStream = btSocket.getOutputStream();
//
//            } catch (IOException e) {
//                Log.e("error", "ON RESUME: Output stream creation failed.", e);
//                return "Socket 流创建失败";
//            }
//
//
//            return "蓝牙连接正常,Socket 创建成功";
//        }
//
//        @Override    //这个方法是在主线程中运行的，所以可以更新界面
//        protected void onPostExecute(String result) {
//            // TODO Auto-generated method stub
//
//            //连接成功则启动监听
//            rThread=new ReceiveThread();
//
//            rThread.start();
//
//            statusLabel.setText(result);
//
//            super.onPostExecute(result);
//        }
//
//
//
//    }
//
//    //发送数据到蓝牙设备的异步任务
//    class SendInfoTask extends AsyncTask<String,String,String>
//    {
//
//        @Override
//        protected void onPostExecute(String result) {
//            // TODO Auto-generated method stub
//            super.onPostExecute(result);
//
//            statusLabel.setText(result);
//
//            //将发送框清空
//            etSend.setText("");
//        }
//
//        @Override
//        protected String doInBackground(String... arg0) {
//            // TODO Auto-generated method stub
//
//            if(btSocket==null)
//            {
//                return "还没有创建连接";
//            }
//
//            if(arg0[0].length()>0)//不是空白串
//            {
//                //String target=arg0[0];
//
//                byte[] msgBuffer = arg0[0].getBytes();
//
//                try {
//                    //  将msgBuffer中的数据写到outStream对象中
//                    outStream.write(msgBuffer);
//
//                } catch (IOException e) {
//                    Log.e("error", "ON RESUME: Exception during write.", e);
//                    return "发送失败";
//                }
//
//            }
//
//            return "发送成功";
//        }
//
//    }
//
//
//    //从蓝牙接收信息的线程
//    class ReceiveThread extends Thread
//    {
//
//        String buffer="";
//
//        @Override
//        public void run() {
//
//            while(btSocket!=null )
//            {
//                //定义一个存储空间buff
//                byte[] buff=new byte[1024];
//                try {
//                    inStream = btSocket.getInputStream();
//                    System.out.println("waitting for instream");
//                    inStream.read(buff); //读取数据存储在buff数组中
////                        System.out.println("buff receive :"+buff.length);
//
//
//                    processBuffer(buff,1024);
//
//                    //System.out.println("receive content:"+ReceiveData);
//                } catch (IOException e) {
//
//                    e.printStackTrace();
//                }
//            }
//        }
//
//        private void processBuffer(byte[] buff,int size)
//        {
//            int length=0;
//            for(int i=0;i<size;i++)
//            {
//                if(buff[i]>'\0')
//                {
//                    length++;
//                }
//                else
//                {
//                    break;
//                }
//            }
//
////			System.out.println("receive fragment size:"+length);
//
//            byte[] newbuff=new byte[length];  //newbuff字节数组，用于存放真正接收到的数据
//
//            for(int j=0;j<length;j++)
//            {
//                newbuff[j]=buff[j];
//            }
//
//            ReceiveData=ReceiveData+new String(newbuff);
//            Log.e("Data",ReceiveData);
////			System.out.println("result :"+ReceiveData);
//            Message msg=Message.obtain();
//            msg.what=1;
//            handler.sendMessage(msg);  //发送消息:系统会自动调用handleMessage( )方法来处理消息
//
//        }
//
//    }
//
//
//
//    //更新界面的Handler类
//    class MyHandler extends Handler{
//
//        @Override
//        public void handleMessage(Message msg) {
//
//            switch(msg.what){
//                case 1:
//                    etReceived.setText(ReceiveData);
//                    break;
//            }
//        }
//    }
//
//    @Override
//    protected void onDestroy() {
//        // TODO Auto-generated method stub
//        super.onDestroy();
//
//        try {
//            if(rThread!=null)
//            {
//
//                btSocket.close();
//                btSocket=null;
//
//                rThread.join();
//            }
//
//            this.finish();
//
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (InterruptedException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//
//    }
//
//}


}